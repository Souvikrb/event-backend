import React, { useEffect, useState } from 'react';
import UserMenu from '../../../../components/userMenu/UserMenu';
import { Button } from '@mui/material';
import useApiHandlers from '../../../../api/ApiHandlers';
import ApiPaths from '../../../../api/ApiPaths';
import useResponse from '../../../../customHooks/useResponse';

const ActivityInfo = () => {
    const [formData, setFormData] = useState({
        _id: "",
        email: "",
        name: "",
        destination: "",
        definition: "",
        workingHours: ""
    });
    const { getApiHandler,putApiHandler } = useApiHandlers();
    const { notify } = useResponse();
    useEffect(() => {
        const fetchData = async () => {
            const response = await getApiHandler(`${ApiPaths.users}`);
            console.log(response);
            setFormData(response.data);

        };
        fetchData();
    }, [])
    const [errors, setErrors] = useState({});

    const validateForm = () => {
        let newErrors = {};
        if (!formData.destination) newErrors.destination = "Destination is required";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async () => {
        if (!validateForm()) return;
        try {
            const response = await putApiHandler(`${ApiPaths.users}/${formData._id}`, formData);
            notify({ title: "Success!", text: response.data, icon: "success" });
        } catch (error) {
            notify({ title: "Error!", text: "Error submitting form", icon: "error" });
        }
    };

    return (
        <div className="bg-white text-black pb-[100px] mt-[55px]">
            <UserMenu />
            <div className="flex flex-col gap-3 px-3 my-8">
                <input
                    name="destination"
                    className="bg-white border border-[#B4B4B4] text-gray-500 rounded-full pl-4 pr-12 py-3 w-full"
                    placeholder="Destination"
                    value={formData.destination}
                    onChange={handleChange}

                />
                {errors.destination && <p className="text-red-500 text-sm">{errors.destination}</p>}

                <input
                    name="definition"
                    className="bg-white border border-[#B4B4B4] text-gray-500 rounded-full pl-4 pr-12 py-3 w-full"
                    placeholder="Definition"
                    value={formData.definition}
                    onChange={handleChange}

                />
                {errors.definition && <p className="text-red-500 text-sm">{errors.definition}</p>}

                <input
                    name="workingHours"
                    className="bg-white border border-[#B4B4B4] text-gray-500 rounded-full pl-4 pr-12 py-3 w-full"
                    placeholder="Working Hours"
                    value={formData.workingHours || ""}
                    maxLength="10"
                    onChange={handleChange}

                />
                {errors.workingHours && <p className="text-red-500 text-sm">{errors.workingHours}</p>}

                <Button
                    variant="contained"
                    fullWidth
                    style={{
                        backgroundColor: "#3ccfcf",
                        color: "white",
                        borderRadius: "30px",
                        fontWeight: "semibold",
                        fontSize: "15px",
                        padding: "10px",
                        letterSpacing: "0.5px",
                    }}
                    onClick={handleSubmit}
                >
                    Modulation
                </Button>
            </div>

        </div>
    );
}

export default ActivityInfo;
