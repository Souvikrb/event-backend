import React, { useRef, useState } from "react";
import {
    Dialog,
    DialogContent,
    Button,
    Switch,
    TextField,
    Checkbox,
    Slide,
    TextareaAutosize,
} from "@mui/material";
import CloseButtonImg from "../../assets/images/close-button.png";
import InfoIcon from "@mui/icons-material/Info";
import ImageGalleryImg from "../../assets/images/outline/image-gallery.png"
import MapImg from '../../assets/images/outline/map.png'
import useApiHandlers from "../../api/ApiHandlers";
import ApiPaths from "../../api/ApiPaths";
import useResponse from "../../customHooks/useResponse";
const AddAdModal = ({ isOpen, onClose }) => {
    const [formData, setFormData] = useState({
        adsname: "",
        fdate: "",
        tdate: "",
        sTime: "",
        eTime: "",
        description: "",
        price: "",
        adsImg: null

    });
    const [selectedImage, setSelectedImage] = useState(null);
    const [errors, setErrors] = useState({});
    const fileInputChange = useRef(null);
    const {getApiHandler,postApiHandler} = useApiHandlers();
    const [resStatus, setResStatus] = useState({
        class: "",
        message: ""
    });
    const {notify} = useResponse();
    const handleChange = (e) => {
        const {name,value} = e.target;
        setFormData({...formData,[name]:value});
    }
    const handleClick = () => {
        fileInputChange.current.click();
    }
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        setFormData({...formData, adsImg:file});
        if(file){
            const imageUrl = URL.createObjectURL(file);
            setSelectedImage(imageUrl);
        }
    }
    const validateForm = () => {
        let newErrors = {};
        if(!formData.adsname) newErrors.adsname = "Ads Name is required";
        if(!formData.fdate) newErrors.fdate = "Ads Date is required";
        if(!formData.price) newErrors.price = "Price is required";
        if(!formData.sTime) newErrors.sTime = "Start Timing is required";
        if(!formData.eTime) newErrors.eTime = "End Timing is required";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    }
    const handleSubmit = async () => {
        if(!validateForm()) return;
        const response = await postApiHandler(ApiPaths.advertisement,formData);
        if(response.status === 201){
            setResStatus({class:"text-green-600",message:response.data.message});
        }else{
            setResStatus({class:"text-red-600",message:response.data.message});
        }
    }
    return (
        <Dialog fullScreen sx={
            {
                '& .MuiDialog-paper': {
                    borderRadius: '0',
                    margin: '20px',
                    width: '100%',
                    maxWidth: '100%',
                    height: '100%',
                    maxHeight: '100%',
                    overflow: 'hidden',
                }
            }
        } open={isOpen} onClose={onClose}>
            <DialogContent className="bg-white p-4 sm:p-6">
                <div className="flex justify-between items-center">
                    <h2 className="text-lg sm:text-xl text-[#4FC2CA] font-semibold">
                        ADD AD

                    </h2>
                    <span className={resStatus.class}><b>{resStatus.message}</b></span>
                    <img
                        src={CloseButtonImg}
                        className="cursor-pointer"
                        onClick={onClose}
                        alt="Close"
                    />
                </div>
                <div className=" rounded-xl w-full flex items-center justify-center" style={{ minHeight: 'calc(60vh - 155px)' }}>
                    <div className="flex flex-col p-8 rounded-lg items-center bg-[#e6e4e4]" onClick={handleClick}>
                        <img src={selectedImage ?selectedImage:ImageGalleryImg} className="size-12 text-black" alt="Image Gallery" />
                        <p className="uppercase text-lg font-semibold mt-4">Add a photo</p>
                        <input type="file" ref={fileInputChange} style={{ display: 'none' }} onChange={handleFileChange}/>
                    </div>
                </div>
                <div className="flex flex-col gap-3  mt-2">

                    <input
                        className="bg-white border border-[#B4B4B4] text-gray-500 rounded-full pl-4 pr-12 py-3 w-full"
                        placeholder="adsname"
                        value={formData.adsname}
                        onChange={handleChange}
                        type="text"
                        name="adsname"
                    />
                    {errors.adsname && <p className="text-red-500 text-sm">{errors.adsname}</p>}
                    <input
                        className="bg-white border border-[#B4B4B4] text-gray-500 rounded-full pl-4 pr-12 py-3 w-full custom-date"
                        name="fdate"
                        value={formData.fdate}
                        onChange={handleChange}
                        type="date"

                    />
                    {errors.fdate && <p className="text-red-500 text-sm">{errors.fdate}</p>}
                    <input
                        className="bg-white border border-[#B4B4B4] text-gray-500 rounded-full pl-4 pr-12 py-3 w-full"
                        placeholder="Price"
                        name="price"
                        value={formData.price}
                        onChange={handleChange}

                    />
                    {errors.price && <p className="text-red-500 text-sm">{errors.price}</p>}    
                    <div>
                        <label className="text-gray-500">Start Timing</label>
                        <input
                            className="bg-white border border-[#B4B4B4] text-gray-500 rounded-full pl-4 pr-12 py-3 w-full"
                            placeholder="----   --"
                            name="sTime"
                            value={formData.sTime}
                            onChange={handleChange}
                            type="time"

                        />
                        {errors.sTime && <p className="text-red-500 text-sm">{errors.sTime}</p>}
                    </div>
                    <div>
                        <label className="text-gray-500">End Timing</label>
                        <input
                            className="bg-white border border-[#B4B4B4] text-gray-500 rounded-full pl-4 pr-12 py-3 w-full"
                            placeholder="----   --"
                            name="eTime"
                            value={formData.eTime}
                            onChange={handleChange}
                            type="time"


                        />
                        {errors.eTime && <p className="text-red-500 text-sm">{errors.eTime}</p>}
                    </div>
                    <TextareaAutosize
                        className="bg-white border border-[#B4B4B4] text-gray-500 rounded-xl pl-4 pr-12 py-3 w-full resize-none"
                        placeholder="Description"
                        minRows={4}
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                    />

                    {/* <div className="mt-2 rounded-xl overflow-hidden border border-[#B4B4B4]">
                        <img src={MapImg} />
                    </div> */}
                    <Button
                        variant="contained"
                        fullWidth
                        style={{
                            backgroundColor: "#3ccfcf",
                            color: "black",
                            borderRadius: "30px",
                            fontWeight: "semibold",
                            fontSize: "15px",
                            padding: "10px",
                            letterSpacing: "0.5px",
                        }}
                        onClick={handleSubmit}

                    >
                        Conservation
                    </Button>
                </div>

            </DialogContent>
        </Dialog>
    );
};

export default AddAdModal;
